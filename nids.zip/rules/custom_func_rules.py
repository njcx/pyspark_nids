# -*- coding: utf-8 -*-
# @Author  : nJcx
# @Email   : njcx86@gmail.com


def haha(ck_field):
    if ck_field == 'xxx':
        return True


def ssh_nmap_scan(ck_field):
        return "SSH" in ck_field