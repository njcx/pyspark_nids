# -*- coding: utf-8 -*-
# @Author  : nJcx
# @Email   : njcx86@gmail.com

from utils.check_utils import CheckUtil
from utils.log_ import Logger


logger = Logger.get_logger(__name__)


class Engine(object):
    def __init__(self, rule_type):
        self.rule_type = rule_type
        self.rules_func_list = self.rules_to_func_list()

    def read_rules(self):
        try:
            rules = __import__('rules')
            return getattr(rules, self.rule_type.lower())
        except Exception as e:
            logger.error(str(e))
            return {}

    def rules_to_func_list(self):
        try:
            temp_list = []
            rules = self.read_rules()
            for rule in rules:
                temp_list.append(CheckUtil(rule))
            return temp_list
        except Exception as e:
            logger.error(str(e))
        return temp_list

    def check_line(self, data):
        temp = []
        try:
            for rule_func in self.rules_func_list:
                temp.append(rule_func.check_res(data))
            return temp
        except Exception as e:
            logger.error(str(e))
        return temp


if __name__ == '__main__':
    test = Engine(rule_type='SSH')

    data = {
      "ts": 1586852099.89234,
      "id.resp_h": "10.18.252.121",
      "uid": "CtJwAA2XWyrbnfKztd",
      "id.resp_p": 22,
      "auth_attempts": 0,
      "client": "SSH-2.0-Nmap-SSH2-Hostkey",
      "id.orig_p": 56871,
      "cipher_alg": "aes128-cbc",
      "compression_alg": "none",
      "mac_alg": "hmac-sha1",
      "kex_alg": "diffie-hellman-group1-sha1",
      "server": "SSH-2.0-OpenSSH_7.4",
      "id.orig_h": "172.19.29.44",
      "version": 2,
      "host_key_alg": "Algorithm negotiation failed"
    }

    print(test.check_line(data))



